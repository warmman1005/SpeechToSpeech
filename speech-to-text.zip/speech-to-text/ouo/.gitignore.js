node_modules/
frontend/node_modules/
backend/node_modules/
backend/config.js
